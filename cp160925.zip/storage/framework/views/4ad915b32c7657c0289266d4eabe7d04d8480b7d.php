<!DOCTYPE html>
<html>
<head>
    <title>New Contact Submission</title>
</head>
<body>
    <h1>Contact Form Submission</h1>
    <p><strong>Name:</strong> <?php echo e($formData['name']); ?></p>
    <p><strong>Email:</strong> <?php echo e($formData['email']); ?></p>
    <p><strong>Subject:</strong> <?php echo e($formData['subject']); ?></p>
    <p><strong>Message:</strong></p>
    <p><?php echo e($formData['message']); ?></p>
</body>
</html><?php /**PATH C:\Users\syafr\Desktop\Parakoder\cp\resources\views/contact-form.blade.php ENDPATH**/ ?>