<?php 
    header('Location: public/');